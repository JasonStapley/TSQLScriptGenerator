# TSQLScriptGenerator
Generate TSQL insert statements or stored procedure calls from a select query
